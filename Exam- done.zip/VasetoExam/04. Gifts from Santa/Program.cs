﻿using System;

namespace _04._Gifts_from_Santa
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int M = int.Parse(Console.ReadLine());
            int S = int.Parse(Console.ReadLine());

            for (int i = M; i >= N; i--)
            {
                if (i%2==0 &&i%3==0)
                {
                    if (S % 2 == 0 && S % 3 == 0 && S==i)
                    {
                        break;
                    }

                    Console.WriteLine(i);
                  
                }


                
            }
        }
    }
}
